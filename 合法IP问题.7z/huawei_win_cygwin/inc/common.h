/*
 * common.h
 *
 *  Created on: 2017.5.26
 *      Author: hello_chenchen
 */

#ifndef INC_COMMON_H_
#define INC_COMMON_H_

typedef int CC_INT32;

#define CC_OK 0
#define CC_ERROR 1

#endif /* INC_COMMON_H_ */
